String wd_name = "" ;
String wd_ssid = "";
String wd_password =  "";
